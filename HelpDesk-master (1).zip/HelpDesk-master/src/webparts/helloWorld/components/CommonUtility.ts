import { MSGraphClient } from '@microsoft/sp-http';


export default class CommonUtility {


    // Get a current login user details using graph api 
  public  getLoginUserDetail=async(graphClient):Promise<any>=>{
    let userDetail;
    await graphClient
      .getClient()
      .then(async (client: MSGraphClient) => {
        await client
          .api('me')
          .version("v1.0")
          .select("displayName,id,mail,state,jobTitle,department,onPremisesExtensionAttributes,accountEnabled")
          .get().then(async (Response) => {
            await Response;
            userDetail=Response;
           
          });
      });
    return userDetail;
  }

    //Get list details with all its inbuilt fields.
    public getData(url: string, isReturnJSON?: boolean): Promise<any> {
        return fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json;odata=verbose', "Content-Type": 'application/json;odata=verbose' } }).then((response) => {
            return response.json();
        }, (errorFail) => {
            console.log("error");
        }).then((responseJSON) => {
            return isReturnJSON ? responseJSON.d : responseJSON.d.results;//.AllItems;
        }).catch((error) => {
            return null;
        });
    }

    //will fetch request digest value
    public getValues(site): any {
        try {
            var url = site + '/_api/contextinfo';
            return fetch(url, {
                method: "POST",
                headers: { Accept: "application/json;odata=verbose", "Content-Type": 'application/json;odata=verbose', 'Access-Control-Allow-Origin': '*' },
                credentials: "same-origin"
            }).then((response) => {
                return response.json();
            });
        } catch (error) {
            console.log("getValues: " + error);
        }
    }



    public insertdata(siteAbsoluteUrl: string, listname: string, requestdata): Promise<any> {
        //alert("CU:Insetdata")
        var url = `${siteAbsoluteUrl}/_api/web/lists/getbytitle('${listname}')/items`;
        return new Promise<any>((resolve, reject) => {
            try {
                this.getValues(siteAbsoluteUrl).then((token) => {
                    fetch(url,
                        {
                            method: "POST",
                            credentials: 'same-origin',
                            headers: {
                                Accept: 'application/json',
                                "Content-Type": "application/json;odata=verbose",
                                "X-RequestDigest": token.d.GetContextWebInformation.FormDigestValue
                            },
                            body: requestdata,
                        }).then((response) => {
                            return response.json();
                        }).then((response) => {
                            if (response.Id != undefined) {
                                resolve(response.Id);
                                return response.Id;
                            }
                            else {
                                resolve(response);
                                return response;
                            }
                        }).catch((error) => {
                            reject(error);
                        });
                }, (error) => {
                    console.log(error);
                    reject(error);
                });
            }
            catch (e) {
                console.log(e);
                reject(e);
            }
        });
    }


    //will perform post call for updation of data to list
    public updatedata(siteAbsoluteUrl: string, listname: string, requestdata, id: number) {
        var url = `${siteAbsoluteUrl}/_api/web/lists/getbytitle('${listname}')/items(${id})`;
        return new Promise<any>((resolve, reject) => {
            try {
                this.getValues(siteAbsoluteUrl).then((token) => {
                    fetch(url,
                        {
                            method: "POST",
                            credentials: 'same-origin',
                            headers: {
                                Accept: 'application/json',
                                "Content-Type": "application/json;odata=verbose",
                                "X-RequestDigest": token.d.GetContextWebInformation.FormDigestValue,
                                'IF-MATCH': '*',
                                'X-HTTP-Method': 'MERGE'
                            },
                            body: requestdata,
                        })
                        .then((response) => {

                            resolve(response);
                            return response;
                        })
                        .catch((error) => {
                            reject(error);
                        });
                }, (error) => {
                    console.log(error);
                    reject(error);
                });
            }
            catch (e) {
                console.log(e);
                reject(e);
            }
        });
    }



}