import {
  ClickAwayListener,
  FormControl,
  TextField,
  InputAdornment,
  FormControlLabel,
  makeStyles,
  Radio,
  RadioGroup,
} from "@material-ui/core";
import * as React from 'react';
//import React, { Fragment, memo, useEffect } from "react";
import { Animated } from "react-animated-css";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { Fragment, memo, useEffect } from "react";
import  '../../styles/main.scss';
const PHCLFieldSearchFilter = (props: any) => {
  const { filterValues, onDataChange } = props;
  const classes = useStyles();

  // Set States
  const [filters, setFilters] = React.useState<string>("");
  const [checkCheckvalue, setCheckCheckvalue] = React.useState<any>(null);
  const [searchInput, setSearchInput] = React.useState<string>("");
  const [filterBoxToggle, setFilterBoxToggle] = React.useState<boolean>(false);

  React.useEffect(() => {
    filterValues.map((item: any) => {
      setCheckCheckvalue((prevState: any) => ({
        ...prevState,
        [item.value]: false,
      }));
    });
  }, []);

  const handleClick = () => {
    setFilterBoxToggle((prev) => !prev);
  };

  const handleClickAway = () => {
    setFilterBoxToggle(false);
  };

  // Filter search handler to search user data
  const searchHandleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
    setFilterBoxToggle(false);
    const value: any = event.target.value;
    setSearchInput(value);
    onDataChange(filters, value);
  };

  // on filter close
  useEffect(() => {
    if (!filterBoxToggle) {
      onDataChange(filters, searchInput);
    }
  }, [filterBoxToggle]);

  // If user not exist
  const checkboxHandler = (e: any) => {
    const value = e.target.value;
    setFilters(value);
  };

  const clearFilterHandler = () => {
    setFilters("");
    filterValues.map((item: any) => {
      setCheckCheckvalue((prevState: any) => ({
        ...prevState,
        [item.value]: false,
      }));
    });
    setSearchInput(searchInput);
    onDataChange(filters, searchInput);
    setFilterBoxToggle(false);
  };

  const submitHandler = () => {
    onDataChange(filters, searchInput);
    setFilterBoxToggle(false);
  };

  return (
    <Fragment>
      <ClickAwayListener
        mouseEvent="onMouseDown"
        touchEvent="onTouchStart"
        onClickAway={handleClickAway}
      >
        <div className="search">
          <Animated
            animationIn="fadeInUp"
            animationOut="fadeOut"
            animationInDelay={100}
            isVisible={true}
          >
            <FormControl
              fullWidth
              className="search-selectbox"
              onClick={handleClick}
            >
              <span>
                Filter <ExpandMoreIcon />
              </span>
            </FormControl>
            <TextField
              autoComplete="off"
              fullWidth
              variant="outlined"
              name="search"
              className="filter-search"
              onChange={searchHandleChange}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    {/* <FontAwesomeIcon
                      icon={["far", "search"]}
                      color="#006bb6"
                      style={{ fontSize: "18px", fontWeight: 800 }}
                    /> */}
                  </InputAdornment>
                ),
              }}
            />
            {filterBoxToggle ? (
              <div className="search_filter open">
                <div className="search_filter-header">
                  <h6>Filter by</h6>
                </div>
                <div>
                  <RadioGroup
                    name="filters"
                    onChange={checkboxHandler}
                    row
                    value={filters}
                  >
                    <div className="search_filter-content">
                      {filterValues &&
                        filterValues.map((e: any) => (
                          <FormControlLabel
                            value={e.value}
                            control={
                              <Radio
                                className={classes.root}
                                disableRipple
                                color="default"
                                checkedIcon={
                                  <span
                                    className={
                                      (classes.icon, classes.checkedIcon)
                                    }
                                  />
                                }
                                icon={<span className={classes.icon} />}
                                {...props}
                              />
                            }
                            label={e.label}
                          />
                        ))}
                    </div>
                  </RadioGroup>
                </div>
                <div className="search_filter-footer">
                  <button
                    onClick={clearFilterHandler}
                    className="cancel"
                    disabled={filters.length === 0}
                  >
                    Clear
                  </button>
                  <button
                    type="button"
                    onClick={submitHandler}
                    className="apply"
                    disabled={filters.length === 0}
                  >
                    Apply
                  </button>
                </div>
              </div>
            ) : null}
          </Animated>
        </div>
      </ClickAwayListener>
    </Fragment>
  );
};

export default memo(PHCLFieldSearchFilter);

// Init custom css in Material Ui theme
const useStyles = makeStyles((theme) => ({
  menuPaper: {
    maxHeight: 300,
  },
  root: {
    "&:hover": {
      backgroundColor: "transparent",
    },
  },
  icon: {
    borderRadius: "50%",
    width: 16,
    height: 16,
    boxShadow:
      "inset 0 0 0 1px rgba(16,22,26,.2), inset 0 -1px 0 rgba(16,22,26,.1)",
    backgroundColor: "#f5f8fa",
    backgroundImage:
      "linear-gradient(180deg,hsla(0,0%,100%,.8),hsla(0,0%,100%,0))",
    "$root.Mui-focusVisible &": {
      outline: "2px auto rgba(19,124,189,.6)",
      outlineOffset: 2,
    },
    "input:hover ~ &": {
      backgroundColor: "#ebf1f5",
    },
    "input:disabled ~ &": {
      boxShadow: "none",
      background: "rgba(206,217,224,.5)",
    },
  },
  checkedIcon: {
    backgroundColor: "#137cbd",
    backgroundImage:
      "linear-gradient(180deg,hsla(0,0%,100%,.1),hsla(0,0%,100%,0))",
    borderRadius: "50%",
    "&:before": {
      display: "block",
      width: 16,
      height: 16,
      backgroundImage: "radial-gradient(#fff,#fff 28%,transparent 32%)",
      content: '""',
    },
    "input:hover ~ &": {
      backgroundColor: "#106ba3",
    },
  },
}));
