import * as React from 'react';
import { AppBar, Grid } from "@material-ui/core";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import '../../styles/main.scss';
import { IHelloWorldProps } from '../IHelloWorldProps';
import CommonUtility from "../CommonUtility";
import { IAplacState } from '../IAplacState';
import { ThumbUpSharp } from '@material-ui/icons';
let Profile: NodeRequire = require("../../assets/images/profil.jpg");
const CU: CommonUtility = new CommonUtility();
//const profile = require("");
export default class Header extends React.Component<IHelloWorldProps, IAplacState> {
  constructor(props) {
    super(props);
    this.state = {
      currentuser: "",
      currentUserProfile: ""
    };
  }

  public async componentDidMount() {
    let currentUser = this.props.context.pageContext.legacyPageContext["userDisplayName"];
    let currentUserProfile = `${this.props.absoluteURL}/_layouts/15/userphoto.aspx?size=S&username=${this.props.context.pageContext.legacyPageContext["userEmail"]}`;
    console.log(this.props.context.pageContext.legacyPageContext,"Lagacy Page Context");
    this.setState({
      currentuser: currentUser,
      currentUserProfile: currentUserProfile
    });
  }
  public render(): React.ReactElement<IHelloWorldProps> {
    return (
      <AppBar className="header" position="static">
        <Grid container alignContent="center">
          <Grid item lg={10} md={10}>
            <div className="header__logo">
              <span className="header__logo--brandname">
                Help Desk Application
              </span>
            </div>
          </Grid>
          <Grid item lg={2} md={2}>
            <ul className="header__menu">
              <li className="header__menu--item">
                <div className="profile">
                  <img src={this.state.currentUserProfile} className="profile--pic" alt="" />
                  <span className="profile--name">{this.state.currentuser}</span>
                </div>
              </li>
            </ul>
          </Grid>
        </Grid>
      </AppBar>
    );
  }

}

