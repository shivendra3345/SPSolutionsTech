
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { AnyRecord } from 'dns';
export interface IHelloWorldProps {
  description?: string;
  context?: WebPartContext;
  currentSite?: string;
  absoluteURL?: string;


  

  //pagenation

  /**
   * The page initial selected
   */
  currentPage?: number;
  /**
   * The total items for which you want to generate pagination
   */
  totalItems?: number;
  /**
   * When the page number change send the page number selected
   */
  onChange?: (pageNo: number, rowsPerPage: number) => void;
  /**
   * The number of pages showing before the icon
   */
  limiter?: number;
  /**
   * Hide the quick jump to the first page
   */
  hideFirstPageJump?: boolean;
  /**
   * Hide the quick jump to the last page
   */
  hideLastPageJump?: boolean;
  /**
   * Limitir icon, by default is More icon
   */
  limiterIcon?: string;
}
