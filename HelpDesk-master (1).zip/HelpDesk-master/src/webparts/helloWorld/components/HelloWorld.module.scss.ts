/* tslint:disable */
require("./HelloWorld.module.css");
const styles = {
  helloWorld: 'helloWorld_dc3cf85a',
  container: 'container_dc3cf85a',
  row: 'row_dc3cf85a',
  column: 'column_dc3cf85a',
  'ms-Grid': 'ms-Grid_dc3cf85a',
  title: 'title_dc3cf85a',
  subTitle: 'subTitle_dc3cf85a',
  description: 'description_dc3cf85a',
  button: 'button_dc3cf85a',
  label: 'label_dc3cf85a'
};

export default styles;
/* tslint:enable */