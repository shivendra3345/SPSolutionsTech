import { IChoiceGroupOption, IDropdownOption } from "office-ui-fabric-react";

export interface IAplacState {
  //Common
currentuser?:string;
currentUserProfile?:string;


//TicketUser
}
