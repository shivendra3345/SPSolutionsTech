import * as React from 'react';
import styles from './HelloWorld.module.scss';
import { IHelloWorldProps } from './IHelloWorldProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { ThemeProvider } from "@material-ui/core";
import { lightTheme } from "../utils/colour-paleete";
import HomePage from "../pages/Home/Home";

export default class HelloWorld extends React.Component<IHelloWorldProps, {}> {
  public render(): React.ReactElement<IHelloWorldProps> {
    return (
      <ThemeProvider theme={lightTheme}>
        <HomePage context={this.props.context} absoluteURL={this.props.absoluteURL}></HomePage>
      </ThemeProvider>
          
    );
  }
}
