import * as React from 'react';

import MoreVertIcon from "@material-ui/icons/MoreVert";
import {
  Avatar,
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  CardMedia,
  Collapse,
  Grid,
  IconButton,
  TextField,
  Typography,
} from "@material-ui/core";
import "../../../styles/main.scss";
import TicketCommentItem from "./TicketCommentItem";

const TicketComments = () => {
  return (
    <div className="ticket__form ticket__comment">
      <h1 className="title">Comments</h1>
      <div className="form">
        <form>
          <Grid container spacing={3}>
            <Grid item md={6}>
              <TextField label="Title" fullWidth variant="outlined" />
            </Grid>
            <Grid item md={12}>
              <TextField
                label="Summary"
                fullWidth
                variant="outlined"
                multiline
              />
            </Grid>
            <Grid item md={12}>
              <Button color="primary" variant="contained">
                Add Comment
              </Button>
            </Grid>
          </Grid>
        </form>
        <div className="ticket__comment_list">
          <TicketCommentItem />
          <TicketCommentItem />
          <TicketCommentItem />
        </div>
      </div>
    </div>
  );
};

export default TicketComments;
