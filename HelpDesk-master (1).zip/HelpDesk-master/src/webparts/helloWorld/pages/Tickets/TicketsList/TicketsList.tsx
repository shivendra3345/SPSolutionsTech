import * as React from 'react';
import {
  Button,
  Dialog,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  TextField,
  Tooltip,
  withStyles,
} from "@material-ui/core";
import { EnhancedTableProps, Order } from "../../../utils/types";
import ArrowDropUpIcon from "@material-ui/icons/ArrowDropUp";
import DeleteIcon from "@material-ui/icons/Delete";
import { Animated } from "react-animated-css";
import CloseIcon from "@material-ui/icons/Close";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
import PersonAddIcon from "@material-ui/icons/PersonAdd";
import CancelIcon from "@material-ui/icons/Cancel";
import EditIcon from "@material-ui/icons/Edit";
import { FC } from 'react';
import "../../../styles/main.scss";
interface TicketProps {
  data: any[];
  headCells?: any;
}

const TicketsList: FC<TicketProps> = (props) => {
  const { data, headCells } = props;

  const [order, setOrder] = React.useState<Order>("desc");
  const [orderBy, setOrderBy] = React.useState("");
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [openModel, setOpenModel] = React.useState<boolean>(false);

  function EnhancedTableHead(props: EnhancedTableProps<any>) {
    const { onRequestSort } = props;
    const createSortHandler =
      (property: keyof any) => (event: React.MouseEvent<unknown>) => {
        onRequestSort(event, property);
      };

    return (
      <TableHead>
        <TableRow>
          {headCells.map((headCell: any, index: any) => {
            if (headCell.sort === true) {
              return (
                <TableCell
                  key={headCell.id}
                  sortDirection={orderBy === headCell.id ? order : false}
                >
                  <TableSortLabel
                    active={orderBy === headCell.id}
                    direction={orderBy === headCell.id ? order : "asc"}
                    onClick={createSortHandler(headCell.id)}
                    IconComponent={ArrowDropUpIcon}
                  >
                    {headCell.label}
                    {orderBy === headCell.id ? (
                      <span style={{ display: "none" }}>
                        {order === "desc"
                          ? "sorted descending"
                          : "sorted ascending"}
                      </span>
                    ) : null}
                  </TableSortLabel>
                </TableCell>
              );
            } else {
              return <TableCell key={headCell.id}>{headCell.label}</TableCell>;
            }
          })}
        </TableRow>
      </TableHead>
    );
  }

  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: any
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
    const sortingData = {
      offset: page * rowsPerPage,
      limit: rowsPerPage,
      sortBy: property,
      sortType: isAsc ? "DESC" : "ASC",
    };
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
    // dispatch(GetUsers({ offset: newPage * rowsPerPage, limit: rowsPerPage }));
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value));
    // dispatch(GetUsers({ offset: 0, limit: parseInt(event.target.value) }));
  };

  const openModelHandler = (id: any) => {
    setOpenModel(true);
  };

  const closeModenHandler = () => {
    setOpenModel(false);
  };

  return (
    <section className="tickets">
      <TableContainer className="table-container">
        <Table className="table listing">
          <EnhancedTableHead
            order={order}
            orderBy={orderBy}
            onRequestSort={handleRequestSort}
            rowCount={data.length}
          />
          <>
            {data.length > 0 ? (
              <TableBody>
                {data.map((row: any, index: any) => {
                  return (
                    <TableRow hover tabIndex={-1} key={row.id}>
                      <TableCell>#{row.id}</TableCell>
                      <TableCell>{row.title}</TableCell>
                      <TableCell>{row.category}</TableCell>
                      <TableCell>{row.name}</TableCell>
                      <TableCell>{row.assignTo}</TableCell>
                      <TableCell>{row.status}</TableCell>
                      <TableCell>{row.createdDate}</TableCell>
                      <TableCell>{row.dueDate}</TableCell>

                      <TableCell align="center">
                        <BlueTooltip
                          title="Open a New Window"
                          arrow
                          placement="bottom"
                        >
                          <IconButton color="primary">
                            <ExitToAppIcon />
                          </IconButton>
                        </BlueTooltip>
                        <BlueTooltip
                          title="Re-Assign Ticket"
                          arrow
                          placement="bottom"
                        >
                          <IconButton
                            onClick={() => openModelHandler(row.id)}
                            color="primary"
                          >
                            <PersonAddIcon />
                          </IconButton>
                        </BlueTooltip>
                        <BlueTooltip
                          title="Edit Ticket"
                          arrow
                          placement="bottom"
                        >
                          <IconButton color="primary">
                            <EditIcon />
                          </IconButton>
                        </BlueTooltip>
                        <BlueTooltip
                          title="Cancel Ticket"
                          arrow
                          placement="bottom"
                        >
                          <IconButton color="primary">
                            <CancelIcon />
                          </IconButton>
                        </BlueTooltip>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            ) : (
              <TableBody className="nodata">
                <TableRow>
                  <TableCell colSpan={7}>
                    <div className="page_notfound">
                      {/* <img src={""} alt="" /> */}
                      <h5 className="title">No Record Found</h5>
                    </div>
                  </TableCell>
                </TableRow>
              </TableBody>
            )}
          </>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={data.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
      <Dialog onClose={closeModenHandler} open={openModel}>
        <div className="clone-dialog">
          <header className="header">
            <h2>Re-Assign Ticket</h2>
            <Button className="close" onClick={closeModenHandler}>
              <CloseIcon />
            </Button>
          </header>
          <div className="content">
            <Animated
              animationIn="fadeInUp"
              animationOut="fadeOut"
              animationInDelay={200}
              isVisible={true}
            >
              <TextField label="Re-assign" fullWidth variant="outlined" />
            </Animated>
          </div>
          <footer className="footer">
            <Animated
              animationIn="fadeInUp"
              animationOut="fadeOut"
              animationInDelay={150}
              isVisible={true}
            >
              <Button
                type="submit"
                color="primary"
                variant="contained"
                className="button"
                style={{ borderRadius: 30, marginRight: 12 }}
              >
                Yes
              </Button>
            </Animated>
            <Animated
              animationIn="fadeInUp"
              animationOut="fadeOut"
              animationInDelay={200}
              isVisible={true}
            >
              <Button
                variant="contained"
                className="button"
                style={{
                  borderRadius: 30,
                  backgroundColor: "#eb1946",
                  color: "#ffffff",
                }}
                onClick={closeModenHandler}
              >
                Cancel
              </Button>
            </Animated>
          </footer>
        </div>
      </Dialog>
    </section>
  );
};

export default TicketsList;

const BlueTooltip = withStyles({
  arrow: {
    color: "#1e1e2d",
  },
  tooltip: {
    color: "#ffffff",
    backgroundColor: "#1e1e2d",
    fontSize: "13px",
    fontWeight: 500,
    fontFamily: "Open Sans, sans-serif",
  },
})(Tooltip);
