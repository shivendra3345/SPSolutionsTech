import { Grid } from "@material-ui/core";
import * as React from 'react';
import TicketsForm from "./TicketsForm/TicketsForm";
import TicketUser from "./TicketUser/TicketUser";

const Tickets = (props: any) => {
  const { backDashboardClick } = props;
  return (
    <section className="tickets">
      <div className="container">
        <Grid container spacing={3}>
          <Grid item md={3}>
            <TicketUser context={props.context} absoluteURL={props.absoluteURL}/>
          </Grid>
          <Grid item md={9}>
            <TicketsForm backDashboardClick={backDashboardClick} context={props.context} absoluteURL={props.absoluteURL}/>
          </Grid>
        </Grid>
      </div>
    </section>
  );
};

export default Tickets;
