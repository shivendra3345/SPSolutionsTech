import * as React from 'react';
//import { Upload } from "@progress/kendo-react-upload";
//import { guid } from "@progress/kendo-react-common";
import "../../../styles/main.scss";
export class PasteScreenForm extends React.Component {
  constructor(props: any) {
    super(props);
  }

  state = {
    files: [],
  };

  // onAdd = (event: any) => {
  //   console.log(event.newState);
  //   this.setState({
  //     files: event.newState,
  //   });
  // };

  // onRemove = (event: any) => {
  //   this.setState({
  //     files: event.newState,
  //   });
  // };

  // onProgress = (event: any) => {
  //   this.setState({
  //     files: event.newState,
  //   });
  // };

  // onStatusChange = (event: any) => {
  //   this.setState({
  //     files: event.newState,
  //   });
  // };

  // handlePaste = (e: any) => {
  //   if (e.clipboardData.files.length) {
  //     const fileObject = e.clipboardData.files[0];
  //     const file = {
  //       getRawFile: () => fileObject,
  //       name: fileObject.name,
  //       size: fileObject.size,
  //       uid: guid(),
  //       status: 2,
  //       progress: 0,
  //     };

  //     const filesState = this.state.files.map((f: any) => ({ ...f }));
  //     filesState.push(file);

  //     this.setState({ files: filesState });
  //   } else {
  //     alert(
  //       "No image data was found in your clipboard. Copy an image first or take a screenshot."
  //     );
  //   }
  // };

  render() {
    return (
      <div><p>ghsdkfvbsdjhbdfkj</p></div>
      //<div onPaste={this.handlePaste}>
        /* <Upload
          autoUpload={false}
          batch={false}
          multiple={true}
          files={this.state.files}
          onAdd={this.onAdd}
          onRemove={this.onRemove}
          onProgress={this.onProgress}
          onStatusChange={this.onStatusChange}
          withCredentials={false}
          saveUrl={"https://demos.telerik.com/kendo-ui/service-v4/upload/save"}
          removeUrl={
            "https://demos.telerik.com/kendo-ui/service-v4/upload/remove"
          }
        /> */
       // <div className="paste__area">Paste Area</div>
     // </div>
    );
  }
}
