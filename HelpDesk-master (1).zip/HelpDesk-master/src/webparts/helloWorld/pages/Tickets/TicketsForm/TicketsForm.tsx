import * as React from 'react';
import {
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  FormControl,
  Button,
  Checkbox,
  IconButton,
  Tooltip,
  withStyles,
} from "@material-ui/core";
import { PasteScreenForm } from "./PasteScreenForm";
//npm install @syncfusion/ej2-react-inputs
import {
  UploaderComponent,
  RemovingEventArgs,
} from "@syncfusion/ej2-react-inputs";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Autocomplete from "@material-ui/lab/Autocomplete";
import DeleteIcon from "@material-ui/icons/Delete";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import TicketComments from "../TicketComments/TicketComments";
import PrintIcon from "@material-ui/icons/Print";
import { Component, Fragment } from 'react';
import "../../../styles/main.scss";
const SelectOptions = [
  { id: 1, name: "First Option" },
  { id: 2, name: "Second Option" },
];

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

class TicketsForm extends Component<any> {
  // Uploader component
  public uploadObj: any;
  private asyncSettings: object;
  private dropContainerRef;
  private dropContainerEle: any;
  state = {
    selectedDate: new Date(),
  };
  constructor(props: {}) {
    super(props);
    this.dropContainerEle = null;
    this.dropContainerRef = (element: any) => {
      this.dropContainerEle = element;
    };
    this.asyncSettings = {
      saveUrl: "https://ej2.syncfusion.com/services/api/uploadbox/Save",
      removeUrl: "https://ej2.syncfusion.com/services/api/uploadbox/Remove",
    };
  }
  public rendereComplete(): void {
    this.uploadObj.dropArea = this.dropContainerEle;
    this.uploadObj.element.setAttribute("name", "UploadFiles");
    this.uploadObj.dataBind();
  }

  private onChange(args: any): void {
    this.uploadObj.autoUpload = args.checked;
    this.uploadObj.clearAll();
  }
  private onChanged(args: any): void {
    this.uploadObj.sequentialUpload = args.checked;
    this.uploadObj.clearAll();
  }
  private onRemoveFile(args: RemovingEventArgs): void {
    args.postRawFile = false;
  }

  dateChangeHandler = (date: any) => {
    console.log(date);
    this.setState({ selectedDate: date });
  };

  render() {
    return (
      <Fragment>
        <div className="ticket__form">
          <div className="ticket__form__header">
            <div className="tivket_id">#65656565</div>
            <div className="tivket_actions">
              <BlueTooltip title="Print Ticket" arrow placement="bottom">
                <IconButton color="primary">
                  <PrintIcon />
                </IconButton>
              </BlueTooltip>
              <Button color="primary" variant="contained" className="cancel">
                Cancel Ticket
              </Button>
            </div>
          </div>
          <h1 className="title">Add New Ticket</h1>
          <div className="form">
            <form>
              <Grid container spacing={3}>
                <Grid item md={4}>
                  <TextField
                    label="Title of Issue / Request"
                    fullWidth
                    variant="outlined"
                  />
                </Grid>
                <Grid item md={4}>
                  <FormControl variant="outlined" fullWidth>
                    <InputLabel>Category</InputLabel>
                    <Select
                      label="Category"
                      IconComponent={() => <ExpandMoreIcon />}
                    >
                      <MenuItem value="">Select Value</MenuItem>
                      {SelectOptions &&
                        SelectOptions.map((item: any) => (
                          <MenuItem key={item.id} value={item.id}>
                            {item.name}
                          </MenuItem>
                        ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item md={4}>
                  <FormControl variant="outlined" fullWidth>
                    <InputLabel>Property</InputLabel>
                    <Select
                      label="Property"
                      IconComponent={() => <ExpandMoreIcon />}
                    >
                      <MenuItem value="">Select Value</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item md={4}>
                  <FormControl variant="outlined" fullWidth>
                    <InputLabel>Unit</InputLabel>
                    <Select
                      label="Unit"
                      IconComponent={() => <ExpandMoreIcon />}
                    >
                      <MenuItem value="">Select Value</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item md={4}>
                  <FormControl variant="outlined" fullWidth>
                    <InputLabel>Current Unit Type</InputLabel>
                    <Select
                      label="Current Unit Type"
                      IconComponent={() => <ExpandMoreIcon />}
                    >
                      <MenuItem value="">Select Value</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item md={4}>
                  <FormControl variant="outlined" fullWidth>
                    <InputLabel>Proposed Unit Type</InputLabel>
                    <Select
                      label="Proposed Unit Type"
                      IconComponent={() => <ExpandMoreIcon />}
                    >
                      <MenuItem value="">Select Value</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item md={4}>
                  <FormControl variant="outlined" fullWidth>
                    <TextField fullWidth variant="outlined" type="date" />
                  </FormControl>
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={3}>
                    <Grid item md={6}>
                      <FormControl variant="outlined" fullWidth>
                        <Autocomplete
                          multiple
                          options={top100Films}
                          className="custom-autocomplete"
                          disableCloseOnSelect
                          getOptionLabel={(option) => option.title}
                          limitTags={2}
                          renderOption={(option, { selected }) => (
                            <React.Fragment>
                              <Checkbox
                                icon={icon}
                                checkedIcon={checkedIcon}
                                style={{ marginRight: 8 }}
                                checked={selected}
                              />
                              {option.title}
                            </React.Fragment>
                          )}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              variant="outlined"
                              label="Amenity Codes to Add"
                            />
                          )}
                        />
                      </FormControl>
                    </Grid>
                    <Grid item md={6}>
                      <FormControl variant="outlined" fullWidth>
                        <Autocomplete
                          multiple
                          options={top100Films}
                          className="custom-autocomplete"
                          disableCloseOnSelect
                          getOptionLabel={(option) => option.title}
                          limitTags={2}
                          renderOption={(option, { selected }) => (
                            <React.Fragment>
                              <Checkbox
                                icon={icon}
                                checkedIcon={checkedIcon}
                                style={{ marginRight: 8 }}
                                checked={selected}
                              />
                              {option.title}
                            </React.Fragment>
                          )}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              variant="outlined"
                              label="Amenity Codes to Remove"
                            />
                          )}
                        />
                      </FormControl>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <label className="label">
                    PayScan Role Addition: For r_Reno Workflow{" "}
                  </label>
                  <label className="label">Property Manger</label>
                  <Grid container spacing={3}>
                    <Grid item md={6}>
                      <TextField fullWidth variant="outlined" />
                    </Grid>
                    <Grid item md={6}>
                      <TextField fullWidth variant="outlined" />
                    </Grid>
                  </Grid>
                  <label className="label" style={{ marginTop: "15px" }}>
                    Property Manger
                  </label>
                  <Grid container spacing={3}>
                    <Grid item md={6}>
                      <TextField fullWidth variant="outlined" />
                    </Grid>
                    <Grid item md={6}>
                      <TextField fullWidth variant="outlined" />
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <label className="label">
                    Upload multiple files with the file dialog or by dragging
                    and dropping onto the dashed region
                  </label>
                  <UploaderComponent
                    id="fileUpload"
                    type="file"
                    ref={(scope) => {
                      this.uploadObj = scope;
                    }}
                    asyncSettings={this.asyncSettings}
                    removing={this.onRemoveFile.bind(this)}
                  ></UploaderComponent>
                </Grid>
                <Grid item md={12}>
                  <label className="label">Paste Screen Shot or File </label>
                  <PasteScreenForm />
                </Grid>
                <Grid item md={12}>
                  <table className="view_table">
                    <thead>
                      <tr>
                        <th>File</th>
                        <th>File Name</th>
                        <th>Eddit By</th>
                        <th>Created Date</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <img
                            src={require("../../../assets/images/profil.jpg")}
                            className="view__table--img"
                            alt=""
                          />
                        </td>
                        <td>filename.jpg</td>
                        <td>filename.jpg</td>
                        <td>filename.jpg</td>
                        <td>
                          <BlueTooltip
                            title="Delete File"
                            arrow
                            placement="bottom"
                          >
                            <IconButton color="primary">
                              <DeleteIcon />
                            </IconButton>
                          </BlueTooltip>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </Grid>
                <Grid item md={12}>
                  <Grid container spacing={3}>
                    <Grid item md={6}>
                      <TextField
                        label="Assigned To"
                        fullWidth
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item md={6}>
                      <TextField label="Status" fullWidth variant="outlined" />
                    </Grid>
                    <Grid item md={6}>
                      <TextField
                        label="Expected Date"
                        fullWidth
                        variant="outlined"
                      />
                    </Grid>
                    <Grid item md={6}>
                      <TextField
                        label="Due Date"
                        fullWidth
                        variant="outlined"
                      />
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item md={12}>
                  <TextField
                    label="Summary"
                    fullWidth
                    variant="outlined"
                    multiline
                  />
                </Grid>
                <Grid item md={12}>
                  <Button color="primary" variant="contained">
                    Submit
                  </Button>
                  <Button
                    color="secondary"
                    variant="contained"
                    style={{ marginLeft: "15px" }}
                    onClick={this.props.backDashboardClick}
                  >
                    Back to Dashboard
                  </Button>
                </Grid>
              </Grid>
            </form>
          </div>
        </div>
        <TicketComments />
      </Fragment>
    );
  }
}

export default TicketsForm;

const BlueTooltip = withStyles({
  arrow: {
    color: "#1e1e2d",
  },
  tooltip: {
    color: "#ffffff",
    backgroundColor: "#1e1e2d",
    fontSize: "13px",
    fontWeight: 500,
    fontFamily: "Open Sans, sans-serif",
  },
})(Tooltip);

// Top 100 films as rated by IMDb users. http://www.imdb.com/chart/top
const top100Films = [
  { title: "The Shawshank Redemption", year: 1994 },
  { title: "The Godfather", year: 1972 },
  { title: "The Godfather: Part II", year: 1974 },
  { title: "The Dark Knight", year: 2008 },
  { title: "12 Angry Men", year: 1957 },
  { title: "Schindler's List", year: 1993 },
  { title: "Pulp Fiction", year: 1994 },
  { title: "The Lord of the Rings: The Return of the King", year: 2003 },
  { title: "The Good, the Bad and the Ugly", year: 1966 },
  { title: "Fight Club", year: 1999 },
  { title: "The Lord of the Rings: The Fellowship of the Ring", year: 2001 },
  { title: "Star Wars: Episode V - The Empire Strikes Back", year: 1980 },
  { title: "Forrest Gump", year: 1994 },
  { title: "Inception", year: 2010 },
  { title: "The Lord of the Rings: The Two Towers", year: 2002 },
  { title: "One Flew Over the Cuckoo's Nest", year: 1975 },
  { title: "Goodfellas", year: 1990 },
  { title: "The Matrix", year: 1999 },
  { title: "Seven Samurai", year: 1954 },
  { title: "Star Wars: Episode IV - A New Hope", year: 1977 },
  { title: "City of God", year: 2002 },
  { title: "Se7en", year: 1995 },
  { title: "The Silence of the Lambs", year: 1991 },
  { title: "It's a Wonderful Life", year: 1946 },
  { title: "Life Is Beautiful", year: 1997 },
  { title: "The Usual Suspects", year: 1995 },
  { title: "Léon: The Professional", year: 1994 },
  { title: "Spirited Away", year: 2001 },
  { title: "Saving Private Ryan", year: 1998 },
  { title: "Once Upon a Time in the West", year: 1968 },
  { title: "American History X", year: 1998 },
  { title: "Interstellar", year: 2014 },
  { title: "Casablanca", year: 1942 },
  { title: "City Lights", year: 1931 },
  { title: "Psycho", year: 1960 },
  { title: "The Green Mile", year: 1999 },
  { title: "The Intouchables", year: 2011 },
  { title: "Modern Times", year: 1936 },
  { title: "Raiders of the Lost Ark", year: 1981 },
  { title: "Rear Window", year: 1954 },
  { title: "The Pianist", year: 2002 },
  { title: "The Departed", year: 2006 },
  { title: "Terminator 2: Judgment Day", year: 1991 },
  { title: "Back to the Future", year: 1985 },
  { title: "Whiplash", year: 2014 },
  { title: "Gladiator", year: 2000 },
  { title: "Memento", year: 2000 },
  { title: "The Prestige", year: 2006 },
  { title: "The Lion King", year: 1994 },
  { title: "Apocalypse Now", year: 1979 },
  { title: "Alien", year: 1979 },
  { title: "Sunset Boulevard", year: 1950 },
  {
    title:
      "Dr. Strangelove or: How I Learned to Stop Worrying and Love the Bomb",
    year: 1964,
  },
  { title: "The Great Dictator", year: 1940 },
  { title: "Cinema Paradiso", year: 1988 },
  { title: "The Lives of Others", year: 2006 },
  { title: "Grave of the Fireflies", year: 1988 },
  { title: "Paths of Glory", year: 1957 },
  { title: "Django Unchained", year: 2012 },
  { title: "The Shining", year: 1980 },
  { title: "WALL·E", year: 2008 },
  { title: "American Beauty", year: 1999 },
  { title: "The Dark Knight Rises", year: 2012 },
  { title: "Princess Mononoke", year: 1997 },
  { title: "Aliens", year: 1986 },
  { title: "Oldboy", year: 2003 },
  { title: "Once Upon a Time in America", year: 1984 },
  { title: "Witness for the Prosecution", year: 1957 },
  { title: "Das Boot", year: 1981 },
  { title: "Citizen Kane", year: 1941 },
  { title: "North by Northwest", year: 1959 },
  { title: "Vertigo", year: 1958 },
  { title: "Star Wars: Episode VI - Return of the Jedi", year: 1983 },
  { title: "Reservoir Dogs", year: 1992 },
  { title: "Braveheart", year: 1995 },
  { title: "M", year: 1931 },
  { title: "Requiem for a Dream", year: 2000 },
  { title: "Amélie", year: 2001 },
  { title: "A Clockwork Orange", year: 1971 },
  { title: "Like Stars on Earth", year: 2007 },
  { title: "Taxi Driver", year: 1976 },
  { title: "Lawrence of Arabia", year: 1962 },
  { title: "Double Indemnity", year: 1944 },
  { title: "Eternal Sunshine of the Spotless Mind", year: 2004 },
  { title: "Amadeus", year: 1984 },
  { title: "To Kill a Mockingbird", year: 1962 },
  { title: "Toy Story 3", year: 2010 },
  { title: "Logan", year: 2017 },
  { title: "Full Metal Jacket", year: 1987 },
  { title: "Dangal", year: 2016 },
  { title: "The Sting", year: 1973 },
  { title: "2001: A Space Odyssey", year: 1968 },
  { title: "Singin' in the Rain", year: 1952 },
  { title: "Toy Story", year: 1995 },
  { title: "Bicycle Thieves", year: 1948 },
  { title: "The Kid", year: 1921 },
  { title: "Inglourious Basterds", year: 2009 },
  { title: "Snatch", year: 2000 },
  { title: "3 Idiots", year: 2009 },
  { title: "Monty Python and the Holy Grail", year: 1975 },
];
