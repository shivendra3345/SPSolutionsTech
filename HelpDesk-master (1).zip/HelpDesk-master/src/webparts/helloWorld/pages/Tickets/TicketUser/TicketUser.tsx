import * as React from 'react';
import {
  Button,
  Dialog,
  FormControl,
  Grid,
  IconButton,
  TextField,
  Tooltip,
  withStyles,
} from "@material-ui/core";
import EditIcon from "@material-ui/icons/Edit";
import { Animated } from "react-animated-css";
import CloseIcon from "@material-ui/icons/Close";
import "../../../styles/main.scss"
import CommonUtility from "../../../components/CommonUtility";
import { useEffect } from 'react';
const CU: CommonUtility = new CommonUtility();
const TicketUser = (props:any) => {
  const [openModel, setOpenModel] = React.useState<boolean>(false);

  const [Name,setName] =   React.useState<String>("");
  const [JobTitle,setJobTitle] =   React.useState<String>("");
  const [Departments,setDepartment] =   React.useState<String>("");
  const [WorkPhone,setWorkPhone] =   React.useState<String>("");
  const [email,setemail] =   React.useState<String>("");
  let currentUserProfile = `${props.absoluteURL}/_layouts/15/userphoto.aspx?size=S&username=${props.context.pageContext.legacyPageContext["userEmail"]}`;
  const openModelHandler = (id: any) => {
    setOpenModel(true);
  };

  const closeModenHandler = () => {
    setOpenModel(false);
  };


  useEffect(() => {
    // Update the document title using the browser API
      function CurrentUser(){
      let url =  props.absoluteURL +`/_api/SP.UserProfiles.PeopleManager/GetMyProperties`;
     // `/_api/web/currentuser`;
      console.log(url);
       CU.getData(url,true).then((respo)=>{
        console.log(respo);
        setName(respo.DisplayName);
        setemail(respo.Email);
        respo.UserProfileProperties.results.map((data)=>{
          console.log(data)})
      })
    };

    CurrentUser();
  });
  return (
    <div className="ticket__user">
      <div className="action_edit_btn">
        <BlueTooltip title="Edit User" arrow placement="bottom">
          <IconButton onClick={openModelHandler} color="primary">
            <EditIcon />
          </IconButton>
        </BlueTooltip>
      </div>
      <div className="ticket__user_header">
        <img src={currentUserProfile} alt="" />
      </div>
      <div className="ticket__user_content">
        <h6 className="user--name">{Name}</h6>
        <ul className="user__timeline">
          <li>
            Job Title: <span>New Title</span>
          </li>
          <li>
            Department: <span>IT Department</span>
          </li>
          <li>
            Phone Number: <span>0987456787</span>
          </li>
          <li>
            Email: <span>{email}</span>
          </li>
          <li>
            Postal Address:{" "}
            <span>
              Lorem ipsum dolor sit, amet consectetur adipisicing elit.
              Explicabo natus, voluptatem nulla incidunt quo iste porro! Quo
              quisquam nemo ut saepe repellendus placeat dolores eaque! Eaque
              repellat enim error voluptates!
            </span>
          </li>
        </ul>
      </div>
      <div className="ticket__user_footer"></div>
      <Dialog onClose={closeModenHandler} open={openModel}>
        <div className="clone-dialog">
          <header className="header">
            <h2>Search User</h2>
            <Button className="close" onClick={closeModenHandler}>
              <CloseIcon />
            </Button>
          </header>
          <div className="content">
            <Grid container spacing={3}>
              <Grid item md={6}>
                <FormControl fullWidth>
                  <TextField label="Enter Name" fullWidth variant="outlined" />
                </FormControl>
              </Grid>
              <Grid item md={6}>
                <FormControl fullWidth>
                  <TextField label="Enter Title" fullWidth variant="outlined" />
                </FormControl>
              </Grid>
              <Grid item md={6}>
                <FormControl fullWidth>
                  <TextField label="Enter Email" fullWidth variant="outlined" />
                </FormControl>
              </Grid>
              <Grid item md={6}>
                <FormControl fullWidth>
                  <TextField label="Enter Phone" fullWidth variant="outlined" />
                </FormControl>
              </Grid>
              <Grid item md={12}>
                <div className="text-right">
                  <Button
                    type="submit"
                    color="primary"
                    variant="contained"
                    className="button"
                    style={{ borderRadius: 30, marginRight: 12 }}
                  >
                    Search
                  </Button>
                </div>
              </Grid>
            </Grid>
          </div>
        </div>
      </Dialog>
    </div>
  );
};

export default TicketUser;

const BlueTooltip = withStyles({
  arrow: {
    color: "#1e1e2d",
  },
  tooltip: {
    color: "#ffffff",
    backgroundColor: "#1e1e2d",
    fontSize: "13px",
    fontWeight: 500,
    fontFamily: "Open Sans, sans-serif",
  },
})(Tooltip);

