import * as React from 'react';
import {
  Button,
  Grid,
  IconButton,
  Tooltip,
  withStyles,
} from "@material-ui/core";
import PHCLFieldSearchFilter from "../../components/FieldSearchFilter/PHCLFieldSearchFilter";
import { TicketsCells } from "../../utils/table-head-cells";
import TicketsList from "../Tickets/TicketsList/TicketsList";
import DashboardCard from "./DashboardCard/DashboardCard";
import CancelIcon from "@material-ui/icons/Cancel";
import AddCircleIcon from "@material-ui/icons/AddCircleSharp";
import { tickets } from "./tickets";
import  '../../styles/main.scss';
const filterData = [
  { label: "Full Name", value: "name" },
  { label: "Email Id", value: "email" },
];

const Dashboard: React.FC<any> = (props) => {
  const [filtervalue, setFilterValues] = React.useState<string>("");
  const [searchvalue, setSearchValues] = React.useState<string>("");

  return (
    <section className="dashboard">
      <div className="dashboard__blankspace"></div>
      <div className="container">
        <DashboardCard />
        <Grid container alignItems="center" className="dashboard__header">
          <Grid item md={9}>
            <div className="d-flex">
              <div className="heading">
                <BlueTooltip title="Create Ticket" arrow placement="bottom">
                  <IconButton onClick={props.gotToTicket} color="primary">
                    <AddCircleIcon />
                  </IconButton>
                </BlueTooltip>
              </div>
              <div className="filter_group">
                <label htmlFor="">Filters: </label>
                <Button>My Department's Ticket</Button>
                <Button>IT</Button>
                <Button>Marketing</Button>
                <Button>Training</Button>
                <Button>All</Button>
                <Button>Filter by Due Date</Button>
              </div>
            </div>
          </Grid>
          <Grid item md={3}>
            <PHCLFieldSearchFilter
              filterValues={filterData}
              onDataChange={(values: any, searchValue: any) => {
                setFilterValues(values);
                setSearchValues(searchValue);
              }}
            />
          </Grid>
        </Grid>
        <TicketsList data={tickets} headCells={TicketsCells} />
      </div>
    </section>
  );
};

export default Dashboard;

const BlueTooltip = withStyles({
  arrow: {
    color: "#1e1e2d",
  },
  tooltip: {
    color: "#ffffff",
    backgroundColor: "#1e1e2d",
    fontSize: "13px",
    fontWeight: 500,
    fontFamily: "Open Sans, sans-serif",
  },
})(Tooltip);
