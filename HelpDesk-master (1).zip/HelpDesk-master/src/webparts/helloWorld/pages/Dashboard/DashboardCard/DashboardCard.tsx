import * as React from 'react';
import { Grid } from "@material-ui/core";
import ConfirmationNumberIcon from "@material-ui/icons/ConfirmationNumber";
import  '../../../styles/main.scss';

export default function DashboardCard() {
  return (
    <Grid container className="dashboard__points" spacing={2}>
      <Grid item lg={3} md={3}>
        <div className="dashboard__card orange">
          <ConfirmationNumberIcon className="icon" />
          New Tickets
          <span className="number">1</span>
        </div>
      </Grid>
      <Grid item lg={3} md={3}>
        <div className="dashboard__card green">
          <ConfirmationNumberIcon className="icon" />
          Tickets are in Progress
          <span className="number">10</span>
        </div>
      </Grid>
      <Grid item lg={3} md={3}>
        <div className="dashboard__card pink">
          <ConfirmationNumberIcon className="icon" />
          Pending Tickets
          <span className="number">10</span>
        </div>
      </Grid>
      <Grid item lg={3} md={3}>
        <div className="dashboard__card blue">
          <ConfirmationNumberIcon className="icon" />
          Completed in last 3 Months
          <span className="number">10</span>
        </div>
      </Grid>
    </Grid>
  );
}
