import * as React from 'react';
import { Button } from "@material-ui/core";
import DashboardIcon from "@material-ui/icons/Dashboard";
import ConfirmationNumberIcon from "@material-ui/icons/ConfirmationNumber";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";

import Header from "../../components/Header/Header";
import Dashboard from "../Dashboard/Dashboard";
import Tickets from "../Tickets/Tickets";
import { FC, Fragment, useState } from 'react';
import  '../../styles/main.scss';
import { IHelloWorldProps } from '../../components/IHelloWorldProps';
interface HomeProps {}

const HomePage: FC<IHelloWorldProps> = (props) => {
  const [toggle, setToggle] = useState(true);

  const switchMenu = (type: string) => {
    if (type === "dashboard") {
      setToggle(true);
    } else if (type === "ticket") {
      setToggle(false);
    }
  };

  return (
    <Fragment>
      {/* <div className="sidebar">
        <div className="sidebar__header">
          <img src={require("../../assets/images/logo.png")} className="logo" alt="logo" />
        </div>
        <div className="sidebar__Content">
          <ul className="sidebar__menu">
            <li className="sidebar__menu--item">
              <Button
                onClick={() => switchMenu("dashboard")}
                className="link"
                variant="contained"
                color="primary"
              >
                <DashboardIcon />
              </Button>
            </li>
            <li className="sidebar__menu--item">
              <Button
                onClick={() => switchMenu("ticket")}
                className="link"
                variant="contained"
                color="primary"
              >
                <ConfirmationNumberIcon />
              </Button>
            </li>
          </ul>
        </div>
        <div className="sidebar__footer">
          <ul className="sidebar__menu">
            <li className="sidebar__menu--item">
              <Button className="link" variant="contained" color="primary">
                <ExitToAppIcon />
              </Button>
            </li>
          </ul>
        </div>
      </div>
      */}
      <main className="page__wrapper">
        <Header context={props.context} absoluteURL={props.absoluteURL} />
        {toggle ? (
          <Dashboard gotToTicket={() => switchMenu("ticket")} context={props.context} absoluteURL={props.absoluteURL}/>
        ) : (
          <Tickets backDashboardClick={() => switchMenu("dashboard")} context={props.context} absoluteURL={props.absoluteURL}/>
        )}
      </main>
    </Fragment>
  );
};

export default HomePage;
