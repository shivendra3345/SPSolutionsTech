import { createTheme } from "@material-ui/core/styles";

export const lightTheme = createTheme({
  palette: {
    primary: {
      light: "",
      main: "#1e1e2d",
      dark: "",
    },
    secondary: {
      light: "",
      main: "#009ef7",
      dark: "",
    },
    error: {
      light: "e57373",
      main: "#dc3545",
      dark: "d32f2f",
    },
    warning: {
      light: "#ffb74d",
      main: "#F1416C",
      dark: "#f57c00",
    },
    info: {
      light: "#64b5f6",
      main: "#7239EA",
      dark: "#1976d2",
    },
    success: {
      light: "#81c784",
      main: "#50CD89",
      dark: "#388e3c",
    },
  },
});
