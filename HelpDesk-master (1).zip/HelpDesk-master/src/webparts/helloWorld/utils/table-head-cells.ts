export const TicketsCells = [
  { id: "id", label: "#Ticket", sort: true },
  { id: "title", label: "Title", sort: true },
  { id: "category", label: "Category", sort: true },
  { id: "name", label: "Name", sort: true },
  { id: "assignTo", label: "Assign To", sort: true },
  { id: "status", label: "Status", sort: true },
  { id: "createdDate", label: "Date Created", sort: true },
  { id: "duedate", label: "Due Date", sort: true },
  { id: "action", label: "Action", sort: false },
];
