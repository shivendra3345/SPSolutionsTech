// axiosconfig.js
import Axios from "axios";

// configure base url
const axios = Axios.create({
  baseURL: process.env.API_PREFIX,
});

// intercept requests and add authorization token
axios.interceptors.request.use((config: any) => {
  const token = localStorage.getItem("token");

  if (token) {
    config.headers.authorization = `${token}`;
  }

  return config;
});

export default axios;
