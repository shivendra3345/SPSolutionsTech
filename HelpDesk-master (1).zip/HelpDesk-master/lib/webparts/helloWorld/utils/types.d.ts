export declare function descendingComparator<T>(a: T, b: T, orderBy: keyof T): 1 | 0 | -1;
export declare type Order = "asc" | "desc";
export declare function getComparator<Key extends keyof any>(order: Order, orderBy: Key): (a: {
    [key in Key]: number | string;
}, b: {
    [key in Key]: number | string;
}) => number;
export declare function stableSort<T>(array: T[], comparator: (a: T, b: T) => number): T[];
export interface HeadCell<T> {
    disablePadding?: boolean;
    id: keyof T;
    label: string;
}
export interface EnhancedTableProps<T> {
    onRequestSort: (event: React.MouseEvent<unknown>, property: keyof T) => void;
    order: Order;
    orderBy: string;
    rowCount: number;
}
//# sourceMappingURL=types.d.ts.map