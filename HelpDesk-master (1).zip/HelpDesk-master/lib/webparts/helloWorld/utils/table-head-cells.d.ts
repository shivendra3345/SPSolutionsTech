export declare const TicketsCells: {
    id: string;
    label: string;
    sort: boolean;
}[];
//# sourceMappingURL=table-head-cells.d.ts.map