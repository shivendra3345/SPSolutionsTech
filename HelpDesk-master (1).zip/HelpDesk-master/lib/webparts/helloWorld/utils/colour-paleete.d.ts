export declare const lightTheme: import("@material-ui/core/styles").Theme;
//# sourceMappingURL=colour-paleete.d.ts.map