declare const axios: import("axios").AxiosInstance;
export default axios;
//# sourceMappingURL=axiosconfig.d.ts.map