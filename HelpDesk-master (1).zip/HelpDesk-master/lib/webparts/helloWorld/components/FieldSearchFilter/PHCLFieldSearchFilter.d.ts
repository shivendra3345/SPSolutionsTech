import * as React from 'react';
import '../../styles/main.scss';
declare const _default: React.MemoExoticComponent<(props: any) => JSX.Element>;
export default _default;
//# sourceMappingURL=PHCLFieldSearchFilter.d.ts.map