import * as React from 'react';
import '../../styles/main.scss';
import { IHelloWorldProps } from '../IHelloWorldProps';
import { IAplacState } from '../IAplacState';
export default class Header extends React.Component<IHelloWorldProps, IAplacState> {
    constructor(props: any);
    componentDidMount(): Promise<void>;
    render(): React.ReactElement<IHelloWorldProps>;
}
//# sourceMappingURL=Header.d.ts.map