export interface IAplacState {
    currentuser?: string;
    currentUserProfile?: string;
}
//# sourceMappingURL=IAplacState.d.ts.map