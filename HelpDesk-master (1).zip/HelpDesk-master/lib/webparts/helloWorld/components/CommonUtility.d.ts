export default class CommonUtility {
    getLoginUserDetail: (graphClient: any) => Promise<any>;
    getData(url: string, isReturnJSON?: boolean): Promise<any>;
    getValues(site: any): any;
    insertdata(siteAbsoluteUrl: string, listname: string, requestdata: any): Promise<any>;
    updatedata(siteAbsoluteUrl: string, listname: string, requestdata: any, id: number): Promise<any>;
}
//# sourceMappingURL=CommonUtility.d.ts.map