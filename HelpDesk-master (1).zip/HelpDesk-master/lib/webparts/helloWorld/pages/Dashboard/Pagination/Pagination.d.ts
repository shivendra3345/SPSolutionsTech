import * as React from "react";
import '../../styles/main.scss';
export interface IPaginationProps {
    /**
     * The page initial selected
     */
    currentPage: number;
    /**
     * The total items for which you want to generate pagination
     */
    totalItems: number;
    /**
     * When the page number change send the page number selected
     */
    onChange: (pageNo: number, rowsPerPage: number) => void;
    /**
     * The number of pages showing before the icon
     */
    limiter?: number;
    /**
     * Hide the quick jump to the first page
     */
    hideFirstPageJump?: boolean;
    /**
     * Hide the quick jump to the last page
     */
    hideLastPageJump?: boolean;
    /**
     * Limitir icon, by default is More icon
     */
    limiterIcon?: string;
    rowsPerPage?: number;
}
export interface IPaginationState {
    totalPages: number;
    currentPage: number;
    paginationElements: number[];
    limiter: number;
    rowsPerPage?: number;
}
export declare class Pagination extends React.Component<IPaginationProps, IPaginationState> {
    constructor(props: Readonly<IPaginationProps>);
    componentDidMount(): void;
    private getTotalPages;
    componentDidUpdate(prevProps: IPaginationProps): void;
    render(): React.ReactElement<IPaginationProps>;
    private preparePaginationElements;
    private onClick;
    private renderPageNumber;
}
//# sourceMappingURL=Pagination.d.ts.map