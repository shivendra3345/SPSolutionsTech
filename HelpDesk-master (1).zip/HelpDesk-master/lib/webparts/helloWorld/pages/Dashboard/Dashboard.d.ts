import * as React from 'react';
import '../../styles/main.scss';
declare const Dashboard: React.FC<any>;
export default Dashboard;
//# sourceMappingURL=Dashboard.d.ts.map