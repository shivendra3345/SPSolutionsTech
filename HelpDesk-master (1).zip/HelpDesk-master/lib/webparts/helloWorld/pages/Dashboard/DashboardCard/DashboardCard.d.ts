import '../../../styles/main.scss';
export default function DashboardCard(): JSX.Element;
//# sourceMappingURL=DashboardCard.d.ts.map