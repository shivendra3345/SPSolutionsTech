export declare const tickets: any[];
//# sourceMappingURL=tickets.d.ts.map