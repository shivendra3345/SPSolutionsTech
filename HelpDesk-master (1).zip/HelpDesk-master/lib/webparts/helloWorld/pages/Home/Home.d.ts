import { FC } from 'react';
import '../../styles/main.scss';
import { IHelloWorldProps } from '../../components/IHelloWorldProps';
declare const HomePage: FC<IHelloWorldProps>;
export default HomePage;
//# sourceMappingURL=Home.d.ts.map