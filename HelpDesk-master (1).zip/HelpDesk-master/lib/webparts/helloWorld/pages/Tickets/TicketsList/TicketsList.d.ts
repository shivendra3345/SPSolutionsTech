import { FC } from 'react';
import "../../../styles/main.scss";
interface TicketProps {
    data: any[];
    headCells?: any;
}
declare const TicketsList: FC<TicketProps>;
export default TicketsList;
//# sourceMappingURL=TicketsList.d.ts.map