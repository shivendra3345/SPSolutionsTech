import "../../../styles/main.scss";
declare const TicketUser: (props: any) => JSX.Element;
export default TicketUser;
//# sourceMappingURL=TicketUser.d.ts.map