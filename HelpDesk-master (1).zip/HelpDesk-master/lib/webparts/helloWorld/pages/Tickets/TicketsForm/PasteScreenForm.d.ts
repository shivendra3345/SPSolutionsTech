import * as React from 'react';
import "../../../styles/main.scss";
export declare class PasteScreenForm extends React.Component {
    constructor(props: any);
    state: {
        files: any[];
    };
    render(): JSX.Element;
}
//# sourceMappingURL=PasteScreenForm.d.ts.map