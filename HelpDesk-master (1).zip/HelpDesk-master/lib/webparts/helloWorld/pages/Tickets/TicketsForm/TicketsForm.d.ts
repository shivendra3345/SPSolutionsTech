import { Component } from 'react';
import "../../../styles/main.scss";
declare class TicketsForm extends Component<any> {
    uploadObj: any;
    private asyncSettings;
    private dropContainerRef;
    private dropContainerEle;
    state: {
        selectedDate: Date;
    };
    constructor(props: {});
    rendereComplete(): void;
    private onChange;
    private onChanged;
    private onRemoveFile;
    dateChangeHandler: (date: any) => void;
    render(): JSX.Element;
}
export default TicketsForm;
//# sourceMappingURL=TicketsForm.d.ts.map