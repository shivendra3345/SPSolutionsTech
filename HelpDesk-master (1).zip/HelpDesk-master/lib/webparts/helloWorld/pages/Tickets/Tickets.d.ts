declare const Tickets: (props: any) => JSX.Element;
export default Tickets;
//# sourceMappingURL=Tickets.d.ts.map