import "../../../styles/main.scss";
declare const TicketCommentItem: () => JSX.Element;
export default TicketCommentItem;
//# sourceMappingURL=TicketCommentItem.d.ts.map