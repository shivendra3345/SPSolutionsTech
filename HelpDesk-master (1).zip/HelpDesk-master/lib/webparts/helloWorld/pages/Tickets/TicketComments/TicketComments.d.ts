import "../../../styles/main.scss";
declare const TicketComments: () => JSX.Element;
export default TicketComments;
//# sourceMappingURL=TicketComments.d.ts.map