declare const styles: {};
export default styles;
//# sourceMappingURL=main.scss.d.ts.map